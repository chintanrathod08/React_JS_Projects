import Main from './router/Main'


function App() {
  return (
    <>
      <Main/>
    </>
  )
}

export default App
