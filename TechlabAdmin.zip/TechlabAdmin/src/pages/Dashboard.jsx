import React from 'react'
import Asiderbar from '../components/Asiderbar'
import Header from '../components/Header'
import { useSelector } from 'react-redux';
import { PieChart } from '@mui/x-charts/PieChart';
import CountUp from 'react-countup';

function Dashboard() {

    const sidebarOpen = useSelector((state) => state.sidebarOpen);

    const data = [
        { id: 1, value: 20, label: 'Slice 1' },
        { id: 2, value: 30, label: 'Slice 2' },
        { id: 3, value: 50, label: 'Slice 3' },
    ];
    const series = [{ data }];
    const colorPalette = ['#3498db', '#e74c3c', '#2ecc71'];

    return (
        <>
            {/* MainConetent-Section */}
            <section className='w-full h-full flex'>
                <Asiderbar />

                <section className={`${sidebarOpen ? 'w-[84%] h-[100vh]  duration-300 transition-all' : 'w-[100%] h-[100vh]'}`}>
                    <Header />

                    {/*---- Conent-Section -----*/}
                    <section className='w-[100%] h-[89vh]  bg-[#F5F5F5] flex justify-center pt-5 pb-5 rounded-tl-[8px]'>

                        <section className='w-[90%] md:w-[95%] h-auto' id='content-sec' >

                            {/* ---------------sec-1----------------- */}
                           
                            <section className='w-full h-auto  flex justify-between'>

                                  {/* ----------------------*/}
                                <div className='shadow-lg rounded-[8px] bg-[white] h-[300px] w-[350px] flex items-center justify-center'>
                                    <PieChart
                                        series={series}
                                        colorPalette={colorPalette}
                                        width={250}
                                        height={300}
                                    />
                                </div>


                                {/* --------------------- */}

                                <div className='w-[400px] h-[240px] p-4 shadow-lg rounded-[8px] bg-[white] grid grid-cols-2 '>
                                    
                                    <div className='border-b border-[gray] flex justify-center items-center'>
                                    <CountUp className='font-bold'
                                        start={0}
                                        end={500}
                                        duration={2.5}
                                        separator=","
                                        decimals={2}
                                        prefix=""
                                        suffix=" units"
                                        onStart={() => console.log('Count started!')}
                                        onEnd={() => console.log('Count ended!')}
                                    />
                                    </div>
                                    <div className='border-l border-b border-[gray] border-[gray] flex justify-center items-center'>
                                    <CountUp className='font-bold'
                                        start={0}
                                        end={300}
                                        duration={2.5}
                                        separator=","
                                        decimals={2}
                                        prefix=""
                                        suffix=" units"
                                        onStart={() => console.log('Count started!')}
                                        onEnd={() => console.log('Count ended!')}
                                    />
                                    </div>
                                    <div className='flex justify-center items-center'>
                                    <CountUp className='font-bold'
                                        start={0}
                                        end={200}
                                        duration={2.5}
                                        separator=","
                                        decimals={2}
                                        prefix=""
                                        suffix=" units"
                                        onStart={() => console.log('Count started!')}
                                        onEnd={() => console.log('Count ended!')}
                                    />
                                    </div>
                                    <div className='border-l border-[gray] flex justify-center items-center'>
                                    <CountUp className='font-bold'
                                        start={0}
                                        end={100}
                                        duration={2.5}
                                        separator=","
                                        decimals={2}
                                        prefix=""
                                        suffix=" units"
                                        onStart={() => console.log('Count started!')}
                                        onEnd={() => console.log('Count ended!')}
                                    />
                                    </div>
                                    
                                </div>

                                 {/* --------------------- */}

                            </section>


                        </section>

                    </section>

                </section>

            </section>
        </>
    )
}

export default Dashboard
